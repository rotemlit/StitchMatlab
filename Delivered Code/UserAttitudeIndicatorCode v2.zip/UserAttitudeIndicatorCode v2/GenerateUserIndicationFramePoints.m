function res = GenerateUserIndicationFramePoints(theta, phi, omega, minTheta, minPhi, minOmega, thetaScale, phiScale, omegaScale, aspectRatio, outerMargin, innerMargin, topBarMargin, bottomBarMargin)
% The function generates the 4 user indicator points.
% Input:
%   theta - tilt angle (float, deg)
%   phi - roll angle (float, deg)
%   omega - pan angle (float, deg)
%   minTheta, minPhi, minOmeta - minimal angle to start moving the indicator (float, deg)
%   thetaScale, phiScale, omegaScale - scale factor on the angles when needed (float, deg)
%   aspectRatio - screen dimensions ratio - height/width
%   outerMargin - boundary of the outer frame, expressed as a ratio
%   relative to the smaller axis of the screen
%   innerMargin - boundary of the inner frame (user indicator when fronto-parallel) from the outer frame, expressed as a ratio relative to the smaller axis of the screen
%   topBarMargin - additional top boundary of the inner frame from the outer frame, expressed as a ratio relative to the smaller axis of the screen
%   bottomMarMargin - additional bottom boundary of the inner frame from the outer frame, expressed as a ratio relative to the smaller axis of the screen
% Output:
%   res - 2x4 array of 2d ordered user indicator points. The span of the
%   points is in the range [0,1] in x and [0,aspectRatio] in y (in some
%   configurations it may exceed these ranges, in which case they should be
%   clipped in the drawing)

doRescale = true; % const

theta = ScaleAndThresholdAngle(theta,minTheta,thetaScale);
phi      = ScaleAndThresholdAngle(phi,minPhi,phiScale);
omega = ScaleAndThresholdAngle(omega,minOmega,omegaScale);

depth = 1; %const
pIn = [-0.5 -aspectRatio/2 -depth;
        0.5 -aspectRatio/2 -depth;
        0.5  aspectRatio/2 -depth;
       -0.5  aspectRatio/2 -depth]';
R = rotationAroundZ(phi*pi/180) * rotationAroundX(theta*pi/180) * rotationAroundY(omega*pi/180);

if (aspectRatio < 1)
    outerMargin = outerMargin * aspectRatio;
    innerMargin = innerMargin * aspectRatio;
end

pOut = R * pIn;
closest = max(pOut(3,:)); % protect from points going behind the "camera" - limit the perspective
minDist = -0.2; % const
if (closest > minDist)
    pOut(3,:) = pOut(3,:) + minDist - closest;
end
res = zeros(2,4);

xMarginScale = 1-(outerMargin+innerMargin);

for i=1:4
    res(1,i) = pOut(1,i) * depth * xMarginScale / pOut(3,i);
    yMarginScale = 1-(1-xMarginScale+topBarMargin+bottomBarMargin)/aspectRatio;
    res(2,i) = pOut(2,i) * depth * yMarginScale / pOut(3,i);
end
frameAScales = [1-outerMargin;aspectRatio-outerMargin-topBarMargin-bottomBarMargin];
if (doRescale)
    size = max(res,[],2)-min(res,[],2);
    scale = max(size./frameAScales);
    if (scale > 1)
        res = res / scale;
    end
end
newCenter = (max(res,[],2)+min(res,[],2))/2;
for i=1:4
    res(:,i) = res(:,i) - newCenter - pIn(1:2,1) + [0;(topBarMargin-bottomBarMargin)/2];
end

function res = ScaleAndThresholdAngle(angle,minAngle,angleScale)
res = sign(angle)*max(0,(abs(angle)-minAngle)/angleScale);