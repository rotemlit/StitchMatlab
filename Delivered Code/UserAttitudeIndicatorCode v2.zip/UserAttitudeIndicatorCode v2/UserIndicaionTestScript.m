% state enum:
global STATE_OK
global STATE_MINOR_PROBLEM
global STATE_SEVERE_PROBLEM
global STATE_STOP_SCAN

angleTestSets = [   0 0 0;
                    5 0 0;
                    0 5 0;
                    0 0 5;
                    -10 0 0;
                    0 -10 0;
                    0 0 -10;
                    10 3 7;
                    5 2 18;
                    6 8 28];
                
%parameters:
aspectRatio = 3/2; % 2/3 for landscape
outerBoundaryMargin = 0.05;
innerBoundaryMargin = 0.05;
topBarMargin = 0.1;
bottomBarMargin = 0.2;
minTheta = 2;
minPhi = 2;
minOmega = 2;
thetaScale = 1;
phiScale = 1;
omegaScale = 1;

minorProblemThreshTPO_Internal = [8 5 5]; % internal minimal angles for minor problem state [theta phi omega], in angles (float array 1x3)
severeProblemThreshTPO_Internal = [20 10 10]; % internal minimal angles for severe problem state [theta phi omega], in angles (float array 1x3)
stopScanThreshTPO_Internal = [30 15 15]; % internal minimal angles for stop scan state [theta phi omega], in angles (float array 1x3)
minorProblemThreshTPO_External = [10 4 12]; % external minimal angles for minor problem state [theta phi omega], in angles (float array 1x3)
severeProblemThreshTPO_External = [25 12 12]; % external minimal angles for severe problem state [theta phi omega], in angles (float array 1x3)
stopScanThreshTPO_External = [25 17 17]; % external minimal angles for stop scan state [theta phi omega], in angles (float array 1x3)

pScreen = [0 0; % screen frame
       1 0;
       1 aspectRatio;
       0 aspectRatio;
       0 0 ]';

figure;
for i=1:size(angleTestSets,1)
    subplot(2,5,i);
    P = GenerateUserIndicationFramePoints(angleTestSets(i,1),angleTestSets(i,2),angleTestSets(i,3),minTheta, minPhi, minOmega,thetaScale,phiScale,omegaScale,aspectRatio,outerBoundaryMargin,innerBoundaryMargin,topBarMargin,bottomBarMargin);
    plot(pScreen(1,:),pScreen(2,:),'b');
    hold on
    pFrame1 = GenerateOuterFrame(aspectRatio,outerBoundaryMargin);
    plot(pFrame1(1,[1 2 3 4 1]),pFrame1(2,[1 2 3 4 1]),'g');
    plot([P(1,:),P(1,1)],[P(2,:),P(2,1)],'ro');
    plot([P(1,:),P(1,1)],[P(2,:),P(2,1)],'r');
    set(gca,'YDir','Reverse')
    title(['\theta=',num2str(angleTestSets(i,1)),', \phi=',num2str(angleTestSets(i,2)),', \omega=',num2str(angleTestSets(i,3))]);
    state = UserAttitudeState(angleTestSets(i,1),angleTestSets(i,2),angleTestSets(i,3),minorProblemThreshTPO_Internal,severeProblemThreshTPO_Internal,stopScanThreshTPO_Internal,minorProblemThreshTPO_External,severeProblemThreshTPO_External,stopScanThreshTPO_External);
    ylabel(['Indication State = ',StateToString(state)]);
    axis equal
    grid on
end
