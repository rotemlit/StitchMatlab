function stateString = StateToString (state)
global STATE_OK
global STATE_MINOR_PROBLEM
global STATE_SEVERE_PROBLEM
global STATE_STOP_SCAN

if (state == STATE_OK)
    stateString = 'OK';
elseif (state == STATE_MINOR_PROBLEM)
    stateString = 'Minor Problem';
elseif (state == STATE_SEVERE_PROBLEM)
    stateString = 'Severe Problem';
elseif (state == STATE_STOP_SCAN)
    stateString = 'Stop Scan';
end
    