function state = UserAttitudeState(theta, phi, omega, minorProblemThreshTPO_Internal,severeProblemThreshTPO_Internal,stopScanThreshTPO_Internal,minorProblemThreshTPO_External,severeProblemThreshTPO_External,stopScanThreshTPO_External)
% The function returns a state (enum) for the user attitude indicator, depending on the 3 input angles theta, phi, omega.
% inputs:
%    theta, phi, omega - attitude angles [deg]
%    minorProblemThreshTPO_Internal - minimal angles for minor problem state [theta phi omega], for internal technical reasons, in angles (float array 1x3)
%    severeProblemThreshTPO_Internal -  minimal angles for severe problem state [theta phi omega], for internal technical reasons, in angles (float array 1x3)
%    stopScanThreshTPO_Internal - minimal angles for stop scan state [theta phi omega], for internal technical reasons, in angles (float array 1x3)
%    minorProblemThreshTPO_External - minimal angles for minor problem state [theta phi omega], for external reasons, in angles (float array 1x3)
%    severeProblemThreshTPO_External -  minimal angles for severe problem state [theta phi omega], for external reasons, in angles (float array 1x3)
%    stopScanThreshTPO_External - minimal angles for stop scan state [theta phi omega], for external reasons, in angles (float array 1x3)
% output:
%    state - result enum (enum values are defined in this function)

% state enum:
global STATE_OK
global STATE_MINOR_PROBLEM
global STATE_SEVERE_PROBLEM
global STATE_STOP_SCAN

STATE_OK = 0;
STATE_MINOR_PROBLEM = 1;
STATE_SEVERE_PROBLEM = 2;
STATE_STOP_SCAN = 3;

minorProblemThreshTPO = min(minorProblemThreshTPO_Internal,minorProblemThreshTPO_External);
severeProblemThreshTPO = min(severeProblemThreshTPO_Internal,severeProblemThreshTPO_External);
stopScanThreshTPO = min(stopScanThreshTPO_Internal,stopScanThreshTPO_External);

assert(min(minorProblemThreshTPO) >= 0 && min(severeProblemThreshTPO) >= 0 && min(severeProblemThreshTPO) >= 0,'angle thresholds must be >= 0');
absAngles = abs([theta, phi, omega]);
if (max(absAngles-stopScanThreshTPO) >= 0)
    state = STATE_STOP_SCAN;
elseif (max(absAngles-severeProblemThreshTPO) >= 0)
        state = STATE_SEVERE_PROBLEM;
elseif (max(absAngles-minorProblemThreshTPO) >= 0)
        state = STATE_MINOR_PROBLEM;
else
    state = STATE_OK;
end
