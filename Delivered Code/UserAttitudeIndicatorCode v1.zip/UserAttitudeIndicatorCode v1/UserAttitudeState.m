function state = UserAttitudeState(theta, phi, omega, minorProblemThreshTPO, severeProblemThreshTPO, stopScanThreshTPO)
% The function returns a state (enum) for the user attitude indicator, depending on the 3 input angles theta, phi, omega.
% inputs:
%    theta, phi, omega - attitude angles [deg]
%    minorProblemThreshTPO - minimal angles for minor problem state [theta phi omega], in angles (float array 1x3)
%    severeProblemThreshTPO -  minimal angles for severe problem state [theta phi omega], in angles (float array 1x3)
%    stopScanThreshTPO - minimal angles for stop scan state [theta phi omega], in angles (float array 1x3)
% output:
%    state - result enum (enum values are defined in this function)

% state enum:
global STATE_OK
global STATE_MINOR_PROBLEM
global STATE_SEVERE_PROBLEM
global STATE_STOP_SCAN

STATE_OK = 0;
STATE_MINOR_PROBLEM = 1;
STATE_SEVERE_PROBLEM = 2;
STATE_STOP_SCAN = 3;

assert(min(minorProblemThreshTPO) >= 0 && min(severeProblemThreshTPO) >= 0 && min(severeProblemThreshTPO) >= 0,'angle thresholds must be >= 0');
absAngles = abs([theta, phi, omega]);
if (max(absAngles-stopScanThreshTPO) >= 0)
    state = STATE_STOP_SCAN;
elseif (max(absAngles-severeProblemThreshTPO) >= 0)
        state = STATE_SEVERE_PROBLEM;
elseif (max(absAngles-minorProblemThreshTPO) >= 0)
        state = STATE_MINOR_PROBLEM;
else
    state = STATE_OK;
end
